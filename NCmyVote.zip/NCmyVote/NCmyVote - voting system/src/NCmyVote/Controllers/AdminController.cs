﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NCmyVote.Models;
using Microsoft.AspNetCore.Authorization;

namespace NCmyVote.Controllers
{
    [Authorize]
    public class AdminController : Controller
    {
        private ICandidateRepository repository;
        public AdminController(ICandidateRepository repo)
        {
            repository = repo;
        }
        public ViewResult Index() => View(repository.Candidates);

        public ViewResult Edit(int candidateId) =>
            View(repository.Candidates
                .FirstOrDefault(p => p.CandidateID == candidateId));

        [HttpPost]
        public IActionResult Edit(Candidate candidate)
        {
            if (ModelState.IsValid)
            {
                repository.SaveCandidate(candidate);
                TempData["message"] = $"{candidate.Name} has been saved";
                return RedirectToAction("Index");
            }
            else
            {
                return View(candidate);
            }
        }

        public ViewResult Create() => View("Edit", new Candidate());

        [HttpPost]
        public IActionResult Delete(int candidateId)
        {
            Candidate deletedCandidate = repository.DeleteCandidate(candidateId);
            if (deletedCandidate != null)
            {
                TempData["message"] = $"{deletedCandidate.Name} was deleted";
            }
            return RedirectToAction("Index");
        }
    }
}
