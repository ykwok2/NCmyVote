﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

namespace NCmyVote.Migrations
{
    public partial class Orders3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Candidates",
                nullable: false);

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "Candidates",
                nullable: false);

            migrationBuilder.AlterColumn<string>(
                name: "Category",
                table: "Candidates",
                nullable: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Candidates",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "Candidates",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Category",
                table: "Candidates",
                nullable: true);
        }
    }
}
