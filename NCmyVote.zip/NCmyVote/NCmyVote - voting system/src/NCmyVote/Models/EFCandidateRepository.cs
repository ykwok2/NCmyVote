﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NCmyVote.Models
{
    public class EFCandidateRepository : ICandidateRepository
    {
        private ApplicationDbContext context;
        public EFCandidateRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }
        public IEnumerable<Candidate> Candidates => context.Candidates;

        public void SaveCandidate(Candidate candidate)
        {
            if (candidate.CandidateID == 0)
            {
                context.Candidates.Add(candidate);
            }
            else
            {
                Candidate dbEntry = context.Candidates
                .FirstOrDefault(p => p.CandidateID == candidate.CandidateID);
                if (dbEntry != null)
                {
                    dbEntry.Name = candidate.Name;
                    dbEntry.Description = candidate.Description;
                    dbEntry.Category = candidate.Category;
                }
            }
            context.SaveChanges();
        }
        public Candidate DeleteCandidate(int candidateID)
        {
            Candidate dbEntry = context.Candidates
            .FirstOrDefault(p => p.CandidateID == candidateID);
            if (dbEntry != null)
            {
                context.Candidates.Remove(dbEntry);
                context.SaveChanges();
            }
            return dbEntry;
        }
    }
}
