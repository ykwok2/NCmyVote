﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NCmyVote.Models
{
    public class FakeCandidateRepository /* : ICandidateRepository*/
    {
        public IEnumerable<Candidate> Candidates => new List<Candidate>
        {
            new Candidate { Name = "Vernon Stewart", Category = "Statewide" },
            new Candidate { Name = "Tim Yarbrough", Category = "CASWELL" },
            new Candidate { Name = "Ron Jones", Category = "CATAWBA" }
        };
    }
}
