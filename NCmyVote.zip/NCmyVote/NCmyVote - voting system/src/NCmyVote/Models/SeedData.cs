﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace NCmyVote.Models
{
    public class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            ApplicationDbContext context = app.ApplicationServices
                .GetRequiredService<ApplicationDbContext>();
            if (!context.Candidates.Any())
            {
                context.Candidates.AddRange(
                new Candidate
                {
                    Name = "Vernon Stewart",
                    Description = "DISTRICT ATTORNEY DISTRICT 11A",
                    Category = "Statewide"
                },
                new Candidate
                {
                    Name = "Buck Newton",
                    Description = "NC ATTORNEY GENERAL",
                    Category = "Statewide"
                },
                new Candidate
                {
                    Name = "Walter Smith",
                    Description = "NC COMMISSIONER OF AGRICULTURE",
                    Category = "Statewide"
                },
                new Candidate
                {
                    Name = "Donald Ray Buie",
                    Description = "NC COURT OF APPEALS JUDGE (GEER)",
                    Category = "Statewide"
                },
                new Candidate
                {
                    Name = "Tom Gamble",
                    Description = "ALAMANCE COUNTY BOARD OF COMMISSIONERS",
                    Category = "ALAMANCE"
                },
                new Candidate
                {
                    Name = "Kendal McBroom",
                    Description = "ALAMANCE COUNTY BOARD OF COMMISSIONERS (UNEXPIRED TERM)",
                    Category = "ALAMANCE"
                },
                new Candidate
                {
                    Name = "Patsy Simpson",
                    Description = "ALAMANCE-BURLINGTON BOARD OF EDUCATION",
                    Category = "ALAMANCE"
                },
                new Candidate
                {
                    Name = "Larry D. Rhodes",
                    Description = "ASHE COUNTY BOARD OF COMMISSIONERS",
                    Category = "ASHE"
                },
                new Candidate
                {
                    Name = "C.B. Jones",
                    Description = "ASHE COUNTY BOARD OF EDUCATION",
                    Category = "ASHE"
                },
                new Candidate
                {
                    Name = "Jeremy Brasch",
                    Description = "MECKLENBURG COUNTY COMMISSI0NER AT-LARGE",
                    Category = "MECKLENBURG"
                },
                new Candidate
                {
                    Name = "Doug Hanks",
                    Description = "SOIL AND WATER CONSERVATION DISTRICT SUPERVISOR",
                    Category = "MECKLENBURG"
                }
                );
                context.SaveChanges();
            }
        }
    }
}
