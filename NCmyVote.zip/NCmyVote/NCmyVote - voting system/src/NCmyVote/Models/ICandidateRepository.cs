﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NCmyVote.Models
{
    public interface ICandidateRepository
    {
        IEnumerable<Candidate> Candidates { get; }

        void SaveCandidate(Candidate candidate);

        Candidate DeleteCandidate(int candidateID);
    }
}
