﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NCmyVote.Models
{
    public class Cart
    {
        private List<CartLine> lineCollection = new List<CartLine>();

        public virtual void AddItem(Candidate candidate, int quantity)
        {
            CartLine line = lineCollection
            .Where(p => p.Candidate.CandidateID == candidate.CandidateID)
            .FirstOrDefault();
            if (line == null)
            {
                lineCollection.Add(new CartLine
                {
                    Candidate = candidate,
                    Quantity = quantity
                });
            }
            else
            {
                line.Quantity += quantity;
            }
        }
        public virtual void RemoveLine(Candidate candidate) =>
                lineCollection.RemoveAll(l => l.Candidate.CandidateID == candidate.CandidateID);

        //public virtual decimal ComputeTotalValue() =>
        //    lineCollection.Sum(e => e.Product.Price * e.Quantity);

        public virtual void Clear() => lineCollection.Clear();
        public virtual IEnumerable<CartLine> Lines => lineCollection;
    }
    public class CartLine
    {
        public int CartLineID { get; set; }
        public Candidate Candidate { get; set; }
        public int Quantity { get; set; }
    }
}
