﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NCmyVote.Models;

namespace NCmyVote.Models.ViewModels
{
    public class CandidatesListViewModel
    {
        public IEnumerable<Candidate> Candidates { get; set; }
        public PagingInfo PagingInfo { get; set; }
        public string CurrentCategory { get; set; }
    }
}

