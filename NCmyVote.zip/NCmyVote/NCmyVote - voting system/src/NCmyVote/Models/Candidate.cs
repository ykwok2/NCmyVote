﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace NCmyVote.Models
{
    public class Candidate
    {
        public int CandidateID { get; set; }

        [Required(ErrorMessage = "Please enter a candidate name")]
        public string Name { get; set; } //name
        [Required(ErrorMessage = "Please enter a description")]
        public string Description { get; set; } //contest_name
        [Required(ErrorMessage = "Please specify a category")]
        public string Category { get; set; } //County
    }
}
